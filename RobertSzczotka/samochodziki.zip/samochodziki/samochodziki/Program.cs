﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;

namespace samochodziki
{
    class Program
    {
        static void Main(string[] args)
        {
            //dotnet run -- --test
            #if DEBUG
            if (args.Length > 0 && args[0] == "--test")
                {
                    UnitTests.RunAllTests();
                    return;
                }
            #endif
            Console.Write("Podaj liczbę tur do symulacji: ");

            if (int.TryParse(Console.ReadLine(), out int numberOfTurns) && numberOfTurns > 0)
            {
                var intersection = new Intersection();

                for (int turn = 1; turn <= numberOfTurns; turn++)
                {
                    Console.Clear();
                    Console.WriteLine($"=== Tura {turn}/{numberOfTurns} ===\n");

                    intersection.SimulateTurn();

                    intersection.DisplayState();

                    if (turn < numberOfTurns)
                    {
                        Console.WriteLine("\nNaciśnij dowolny klawisz, aby przejść do następnej tury...");
                        Console.ReadKey();
                    }
                }

                Console.WriteLine("\n=== Symulacja zakończona ===");
            }
            else
            {
                Console.WriteLine("Nieprawidłowe dane wejściowe. Proszę podać liczbę dodatnią.");
            }

            Console.WriteLine("Naciśnij dowolny klawisz, aby wyjść...");
            Console.ReadKey();
        }
    }

    enum Street
    {
        North,
        East,
        South,
        West
    }

    enum TurnType
    {
        Right,
        Straight,
        Left
    }

    class Vehicle
    {
        public Street Origin { get; }
        public Street Destination { get; }
        public DateTime ArrivalTime { get; }
        public TurnType Turn { get; }

        public Vehicle(Street origin, Street destination)
        {
            Origin = origin;
            Destination = destination;
            ArrivalTime = DateTime.Now;
            Turn = DetermineTurnType(origin, destination);
        }

        private TurnType DetermineTurnType(Street origin, Street destination)
        {
            switch (origin)
            {
                case Street.North:
                    switch (destination)
                    {
                        case Street.East: return TurnType.Right;
                        case Street.South: return TurnType.Straight;
                        case Street.West: return TurnType.Left;
                        default: return TurnType.Left;
                    }
                case Street.East:
                    switch (destination)
                    {
                        case Street.North: return TurnType.Left;
                        case Street.South: return TurnType.Right;
                        case Street.West: return TurnType.Straight;
                        default: return TurnType.Left; 
                    }
                case Street.South:
                    switch (destination)
                    {
                        case Street.North: return TurnType.Straight;
                        case Street.East: return TurnType.Left;
                        case Street.West: return TurnType.Right;
                        default: return TurnType.Left; 
                    }
                case Street.West:
                    switch (destination)
                    {
                        case Street.North: return TurnType.Left;
                        case Street.East: return TurnType.Straight;
                        case Street.South: return TurnType.Right;
                        default: return TurnType.Left; 
                    }
                default:
                    return TurnType.Left; 
            }
        }


        public override string ToString()
        {
            return $"Pojazd z {Origin} jadący do {Destination} ({Turn})";
        }
    }

    class TrafficLight
    {
        public bool IsNorthSouthGreen { get; private set; }
        private Random random = new Random();

        public TrafficLight()
        {
            IsNorthSouthGreen = random.Next(2) == 0;
        }

        public void RandomizeState()
        {
            IsNorthSouthGreen = random.Next(2) == 0;
        }

        public bool CanPass(Street origin)
        {
            bool isOnNorthSouthStreet = origin == Street.North || origin == Street.South;
            return isOnNorthSouthStreet == IsNorthSouthGreen;
        }

        public override string ToString()
        {
            return IsNorthSouthGreen ? "N-S jest ZIELONE, E-W jest CZERWONE" : "N-S jest CZERWONE, E-W jest ZIELONE";
        }
    }

    class Intersection
    {
        private List<Vehicle> waitingVehicles = new List<Vehicle>();
        private TrafficLight trafficLight = new TrafficLight();
        private Random random = new Random();

        public void SimulateTurn()
        {
            AddRandomVehicle();

            trafficLight.RandomizeState();
            Console.WriteLine($"Sygnalizacja świetlna: {trafficLight}");

            MoveOneVehicle();
        }

        private void AddRandomVehicle()
        {
            Street origin = (Street)random.Next(4);

            Street destination;
            do
            {
                destination = (Street)random.Next(4);
            } while (destination == origin);

            Vehicle newVehicle = new Vehicle(origin, destination);
            waitingVehicles.Add(newVehicle);

            Console.WriteLine($"Pojawił się nowy pojazd: {newVehicle}");
        }

        private void MoveOneVehicle()
        {
            var eligibleVehicles = waitingVehicles
                .Where(v => trafficLight.CanPass(v.Origin))
                .ToList();

            if (eligibleVehicles.Any())
            {
                var vehiclesByPriority = eligibleVehicles
                    .GroupBy(v => v.Turn)
                    .OrderBy(g => GetTurnPriority(g.Key))
                    .First()
                    .ToList();

                var vehicleToMove = vehiclesByPriority
                    .OrderBy(v => v.ArrivalTime)
                    .First();

                waitingVehicles.Remove(vehicleToMove);
                Console.WriteLine($"Pojazd się przemieścił: {vehicleToMove}");
            }
            else
            {
                Console.WriteLine("Żaden pojazd nie mógł się przemieścić w tej turze.");
            }
        }

        private int GetTurnPriority(TurnType turn)
        {
            switch (turn)
            {
                case TurnType.Right:
                    return 0;
                case TurnType.Straight:
                    return 1;
                case TurnType.Left:
                    return 2;
                default:
                    return 3;
            }
        }


        public void DisplayState()
        {
            Console.WriteLine("\n=== Aktualny Stan ===");
            Console.WriteLine($"Oczekujące pojazdy: {waitingVehicles.Count}");

            if (waitingVehicles.Any())
            {
                Console.WriteLine("\nPojazdy oczekujące na każdej ulicy:");
                foreach (Street street in Enum.GetValues(typeof(Street)))
                {
                    var vehiclesAtStreet = waitingVehicles
                        .Where(v => v.Origin == street)
                        .ToList();

                    Console.WriteLine($"  {street}: {vehiclesAtStreet.Count} pojazd(ów)");
                    foreach (var vehicle in vehiclesAtStreet)
                    {
                        Console.WriteLine($"    -> {vehicle}");
                    }
                }
            }
        }
    }
#if DEBUG
    class UnitTests
    {
        public static void RunAllTests()
        {
            Console.WriteLine("==== Uruchamianie testów jednostkowych ====");

            TestVehicleTurnTypes();
            TestTrafficLightCanPass();
            TestVehiclePriority();

            Console.WriteLine("==== Wszystkie testy zakończone ====\n");
        }

        private static void TestVehicleTurnTypes()
        {
            Console.WriteLine("- Test: określanie typu skrętu");

            AssertTurnType(Street.North, Street.East, TurnType.Right, "North->East powinien być skrętem w prawo");
            AssertTurnType(Street.North, Street.South, TurnType.Straight, "North->South powinien być jazdą prosto");
            AssertTurnType(Street.North, Street.West, TurnType.Left, "North->West powinien być skrętem w lewo");

            AssertTurnType(Street.East, Street.North, TurnType.Left, "East->North powinien być skrętem w lewo");
            AssertTurnType(Street.East, Street.South, TurnType.Right, "East->South powinien być skrętem w prawo");
            AssertTurnType(Street.East, Street.West, TurnType.Straight, "East->West powinien być jazdą prosto");

            AssertTurnType(Street.South, Street.North, TurnType.Straight, "South->North powinien być jazdą prosto");
            AssertTurnType(Street.South, Street.East, TurnType.Left, "South->East powinien być skrętem w lewo");
            AssertTurnType(Street.South, Street.West, TurnType.Right, "South->West powinien być skrętem w prawo");

            AssertTurnType(Street.West, Street.North, TurnType.Left, "West->North powinien być skrętem w lewo");
            AssertTurnType(Street.West, Street.East, TurnType.Straight, "West->East powinien być jazdą prosto");
            AssertTurnType(Street.West, Street.South, TurnType.Right, "West->South powinien być skrętem w prawo");

            Console.WriteLine("  ✓ Test zakończony pomyślnie");
        }

        private static void AssertTurnType(Street origin, Street destination, TurnType expectedTurn, string message)
        {
            var vehicle = new Vehicle(origin, destination);
            if (vehicle.Turn != expectedTurn)
            {
                Console.WriteLine($"  ✗ BŁĄD: {message}, ale było {vehicle.Turn}");
                throw new Exception($"Test nie powiódł się: {message}");
            }
        }

        private static void TestTrafficLightCanPass()
        {
            Console.WriteLine("- Test: sygnalizacja świetlna");

            var trafficLight = new TrafficLight();

            var isNorthSouthGreenProperty = typeof(TrafficLight).GetProperty("IsNorthSouthGreen");
            if (isNorthSouthGreenProperty == null)
            {
                throw new Exception("Nie znaleziono właściwości IsNorthSouthGreen w klasie TrafficLight");
            }

            isNorthSouthGreenProperty.SetValue(trafficLight, true);

            Assert(trafficLight.CanPass(Street.North), "Północ powinna przejechać przy N-S zielonym");
            Assert(trafficLight.CanPass(Street.South), "Południe powinno przejechać przy N-S zielonym");
            Assert(!trafficLight.CanPass(Street.East), "Wschód nie powinien przejechać przy N-S zielonym");
            Assert(!trafficLight.CanPass(Street.West), "Zachód nie powinien przejechać przy N-S zielonym");

            isNorthSouthGreenProperty.SetValue(trafficLight, false);

            Assert(!trafficLight.CanPass(Street.North), "Północ nie powinna przejechać przy E-W zielonym");
            Assert(!trafficLight.CanPass(Street.South), "Południe nie powinno przejechać przy E-W zielonym");
            Assert(trafficLight.CanPass(Street.East), "Wschód powinien przejechać przy E-W zielonym");
            Assert(trafficLight.CanPass(Street.West), "Zachód powinien przejechać przy E-W zielonym");

            Console.WriteLine("  ✓ Test zakończony pomyślnie");
        }

        private static void TestVehiclePriority()
        {
            Console.WriteLine("- Test: priorytet pojazdów");

            var intersection = new Intersection();

            var waitingVehiclesField = typeof(Intersection).GetField("waitingVehicles",
                System.Reflection.BindingFlags.NonPublic | System.Reflection.BindingFlags.Instance);

            if (waitingVehiclesField == null)
            {
                throw new Exception("Nie znaleziono pola waitingVehicles w klasie Intersection");
            }

            var waitingVehicles = new List<Vehicle>();
            waitingVehiclesField.SetValue(intersection, waitingVehicles);

            var trafficLightField = typeof(Intersection).GetField("trafficLight",
                System.Reflection.BindingFlags.NonPublic | System.Reflection.BindingFlags.Instance);

            if (trafficLightField == null)
            {
                throw new Exception("Nie znaleziono pola trafficLight w klasie Intersection");
            }

            var trafficLight = new TrafficLight();
            trafficLightField.SetValue(intersection, trafficLight);

            var isNorthSouthGreenProperty = typeof(TrafficLight).GetProperty("IsNorthSouthGreen");
            if (isNorthSouthGreenProperty == null)
            {
                throw new Exception("Nie znaleziono właściwości IsNorthSouthGreen w klasie TrafficLight");
            }

            isNorthSouthGreenProperty.SetValue(trafficLight, true);

            var leftTurn = new Vehicle(Street.North, Street.West);
            waitingVehicles.Add(leftTurn);
            System.Threading.Thread.Sleep(10);

            var straightTurn = new Vehicle(Street.North, Street.South);
            waitingVehicles.Add(straightTurn);
            System.Threading.Thread.Sleep(10);

            var rightTurn = new Vehicle(Street.North, Street.East);
            waitingVehicles.Add(rightTurn);

            var methodInfo = typeof(Intersection).GetMethod("MoveOneVehicle",
                System.Reflection.BindingFlags.NonPublic | System.Reflection.BindingFlags.Instance);

            if (methodInfo == null)
            {
                throw new Exception("Nie znaleziono metody MoveOneVehicle w klasie Intersection");
            }

            methodInfo.Invoke(intersection, null);

            Assert(waitingVehicles.Count == 2, "Po pierwszym ruchu powinny pozostać 2 pojazdy");
            Assert(!waitingVehicles.Contains(rightTurn), "Pojazd skręcający w prawo powinien wyjechać pierwszy");

            methodInfo.Invoke(intersection, null);

            Assert(waitingVehicles.Count == 1, "Po drugim ruchu powinien pozostać 1 pojazd");
            Assert(!waitingVehicles.Contains(straightTurn), "Pojazd jadący prosto powinien wyjechać drugi");

            methodInfo.Invoke(intersection, null);

            Assert(waitingVehicles.Count == 0, "Po trzecim ruchu nie powinno być żadnych pojazdów");

            Console.WriteLine("  ✓ Test zakończony pomyślnie");
        }

        private static void Assert(bool condition, string message)
        {
            if (!condition)
            {
                Console.WriteLine($"  ✗ BŁĄD: {message}");
                throw new Exception($"Test nie powiódł się: {message}");
            }
        }
    }
#endif

}
