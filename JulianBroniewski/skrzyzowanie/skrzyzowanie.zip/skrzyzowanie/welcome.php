<?php
echo "Witaj na stronie!";
?>