<?php
// Połączenie z bazą danych
$host = 'localhost';
$dbname = 'baza';
$username = 'root';
$password = '';

try {
    $pdo = new PDO("mysql:host=$host;dbname=$dbname", $username, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    die("Nie udało się połączyć z bazą danych: " . $e->getMessage());
}

// Sprawdzenie, czy formularz został wysłany
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $login = $_POST['login'];
    $password = $_POST['password'];

    // Przygotowanie zapytania do bazy danych
    $stmt = $pdo->prepare("SELECT * FROM users WHERE login = :login");
    $stmt->execute(['login' => $login]);

    // Sprawdzenie, czy użytkownik istnieje
    $user = $stmt->fetch(PDO::FETCH_ASSOC);

    if ($user && $user['password'] === $password) {
        // Hasło jest zgodne, przekierowanie na inną stronę
        header('Location: welcome.php');
        exit();
    } else {
        echo "Niepoprawny login lub hasło.";
    }
}
?>