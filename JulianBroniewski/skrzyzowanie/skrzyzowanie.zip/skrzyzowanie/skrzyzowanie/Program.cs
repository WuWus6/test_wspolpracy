﻿namespace skrzyzowanie
{
    public class Program
    {
        public static Dictionary<string, Queue<string>> roads = [];
        public static string currentRoad;
        public static string currentLights;

        static void Main()
        {
            roads.Add("N", new Queue<string>());
            roads.Add("E", new Queue<string>());
            roads.Add("S", new Queue<string>());
            roads.Add("W", new Queue<string>());

            Console.WriteLine("Podaj ilość tur:");
            string input = Console.ReadLine();
            int number = 0;
            if (int.TryParse(input, out int n))
            {
                Execute(int.Parse(input));
            }
            else
            {
                Console.WriteLine("Nieprawidłowe dane wejściowe");
            }
        }

        // PROGRAM
        public static void Execute(int number)
        {
            Console.WriteLine();

            for (int i = 1; i <= number; i++)
            {
                Console.WriteLine("Tura " + i + ":");

                Console.WriteLine(AddCar(DrawLetter()));
                Console.WriteLine(AddDirection(DrawLetter()));
                Console.WriteLine(ChangeLights(DrawLights()));
                Console.WriteLine(MoveCar());

                Console.WriteLine();
            }

            Console.WriteLine();
            DisplayAftermath();
        }

        // FUNKCJE
        public static string DrawLetter()
        {
            List<string> letters = ["N", "E", "S", "W"];
            Random random = new Random();
            return letters[random.Next(4)];
        }

        public static string DrawLights()
        {
            List<string> directions = ["N, S", "W, E"];
            Random random = new Random();
            string lights = directions[random.Next(2)];
            return lights;
        }

        public static string AddCar(string road)
        {
            currentRoad = road;
            return "Nowy pojazd nadjeżdża z kierunku " + road + ".";
        }

        public static string AddDirection(string direction)
        {
            while (direction == currentRoad)
            {
                direction = DrawLetter();
            }
            roads[currentRoad].Enqueue(direction);
            return "Pojazd ten chce jechać w kierunku " + direction + ".";
        }

        public static string ChangeLights(string lights)
        {
            currentLights = lights;
            return "Światła są zielone dla " + lights + ".";
        }

        public static string MoveCar()
        {
            var availableRoads = roads
                .Where(r => currentLights.Contains(r.Key) && r.Value.Count > 0)
                .ToList();

            if (availableRoads.Count > 1)
            {
                var selectedRoad = availableRoads.OrderByDescending(r => r.Value.Count).First();
                string a = selectedRoad.Value.Dequeue();
                return "Pierwszy pojazd z kierunku " + selectedRoad.Key + " rusza i jedzie w kierunku " + a + ".";
            }
            else if (availableRoads.Count == 1)
            {
                var road = availableRoads.First();
                string a = road.Value.Dequeue();
                return "Pierwszy pojazd z kierunku " + road.Key + " rusza i jedzie w kierunku " + a + ".";
            }

            return "Nie rusza żaden pojazd.";
        }


        public static void DisplayAftermath()
        {
            Console.WriteLine("Korki na drogach:");
            Console.WriteLine("N: " + roads["N"].Count);
            Console.WriteLine("E: " + roads["E"].Count);
            Console.WriteLine("S: " + roads["S"].Count);
            Console.WriteLine("W: " + roads["W"].Count);
        }
    }
}
