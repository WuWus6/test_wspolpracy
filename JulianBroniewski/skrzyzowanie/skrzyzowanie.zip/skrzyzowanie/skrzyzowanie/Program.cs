﻿namespace skrzyzowanie
{
    public class Program
    {
        private static Dictionary<string, Queue<string>> roads = new();
        private static string currentRoad;
        private static string currentLights;

        static void Main()
        {
            roads.Add("N", new Queue<string>());
            roads.Add("E", new Queue<string>());
            roads.Add("S", new Queue<string>());
            roads.Add("W", new Queue<string>());

            Console.WriteLine("Podaj ilość tur:");
            string input = Console.ReadLine();
            int number = 0;
            if (int.TryParse(input, out int n))
            {
                Execute(int.Parse(input));
            }
            else if (input == "T")
            {
                Test();
            }
            else
            {
                Console.WriteLine("Nieprawidłowe dane wejściowe");
            }
        }

        // PROGRAM
        private static void Execute(int number)
        {
            Console.WriteLine();

            for (int i = 1; i <= number; i++)
            {
                Console.WriteLine("Tura " + i + ":");

                Console.WriteLine(DrawCar());
                Console.WriteLine(DrawDirection());
                Console.WriteLine(DrawLights());
                Console.WriteLine(MoveCar());

                Console.WriteLine();
            }

            Console.WriteLine();
            DisplayAftermath();
        }

        // TESTY
        private static void Test()
        {
            Console.WriteLine("Uruchomiono testy");
            Console.WriteLine();

            Console.WriteLine("Testuję funkcję poruszania pojazdami:");
            roads["N"].Enqueue("S");
            roads["N"].Enqueue("W");
            roads["N"].Enqueue("E");

            TestMove("N, S", "Pierwszy pojazd z kierunku N rusza i jedzie w kierunku S.");
            TestMove("W, E", "Nie rusza żaden pojazd.");
            TestMove("N, S", "Pierwszy pojazd z kierunku N rusza i jedzie w kierunku W.");
        }

        // FUNKCJE
        private static string DrawLetter()
        {
            List<string> letters = ["N", "E", "S", "W"];
            Random random = new Random();
            return letters[random.Next(4)];
        }

        private static string DrawCar()
        {
            string a = DrawLetter();
            currentRoad = a;
            return "Nowy pojazd nadjeżdża z kierunku " + a + ".";
        }

        private static string DrawDirection()
        {
            string a;
            do {
                a = DrawLetter();
            } while (a == currentRoad);
            roads[currentRoad].Enqueue(a);
            return "Pojazd ten chce jechać w kierunku " + a + ".";
        }

        private static string DrawLights()
        {
            List<string> directions = ["N, S", "W, E"];
            Random random = new Random();
            string a = directions[random.Next(2)];
            currentLights = a;
            return "Światła są zielone dla " + a + ".";
        }

        private static string MoveCar()
        {
            foreach (var road in roads)
            {
                if (currentLights.Contains(road.Key) && road.Value.Count != 0)
                {
                    string a = road.Value.Dequeue();
                    return "Pierwszy pojazd z kierunku " + road.Key + " rusza i jedzie w kierunku " + a + ".";
                }
            }

            return "Nie rusza żaden pojazd.";
        }

        private static void DisplayAftermath()
        {
            Console.WriteLine("Korki na drogach:");
            Console.WriteLine("N: " + roads["N"].Count);
            Console.WriteLine("E: " + roads["E"].Count);
            Console.WriteLine("S: " + roads["S"].Count);
            Console.WriteLine("W: " + roads["W"].Count);
        }

        private static void TestMove(string lights, string desiredResult)
        {
            currentLights = lights;

            Console.WriteLine("Światła są zielone dla W, E.");
            Console.WriteLine("Oczekiwany komunikat: " + desiredResult);
            string result = MoveCar();
            Console.WriteLine("Otrzymany komunikat: " + result);

            if (desiredResult == result)
            {
                Console.WriteLine("!     TEST POMYŚLNY      !");
            }
            else
            {
                Console.WriteLine("!    TEST NIEPOMYŚLNY    !");
            }

            Console.WriteLine();
        }
    }
}
