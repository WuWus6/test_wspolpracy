﻿namespace skrzyzowanie
{
    class Program
    {
        private static Dictionary<string, Queue<string>> roads = new();
        private static string currentRoad;
        private static string currentLights;

        static void Main()
        {
            roads.Add("N", new Queue<string>());
            roads.Add("E", new Queue<string>());
            roads.Add("S", new Queue<string>());
            roads.Add("W", new Queue<string>());

            Console.WriteLine("Podaj ilość tur:");
            int number = Int32.Parse(Console.ReadLine());

            Console.WriteLine();

            for (int i = 1; i <= number; i++)
            {
                Console.WriteLine("Tura " + i + ":");

                DrawCar();
                DrawDirection();
                DrawLights();
                MoveCar();

                Console.WriteLine();
            }

            Console.WriteLine();
            DisplayAftermath();
        }

        private static string DrawLetter()
        {
            List<string> letters = ["N", "E", "S", "W"];
            Random random = new Random();
            return letters[random.Next(4)];
        }

        private static void DrawCar()
        {
            string a = DrawLetter();
            currentRoad = a;
            Console.WriteLine("Nowy pojazd nadjeżdża z kierunku " + a + ".");
        }

        private static void DrawDirection()
        {
            string a;
            do {
                a = DrawLetter();
            } while (a == currentRoad);
            roads[currentRoad].Enqueue(a);
            Console.WriteLine("Pojazd ten chce jechać w kierunku " + a + ".");
        }

        private static void DrawLights()
        {
            List<string> directions = ["N, S", "W, E"];
            Random random = new Random();
            string a = directions[random.Next(2)];
            currentLights = a;
            Console.WriteLine("Światła są zielone dla " + a + ".");
        }

        private static void MoveCar()
        {
            foreach (var road in roads)
            {
                if (currentLights.Contains(road.Key) && road.Value.Count != 0)
                {
                    string a = road.Value.Dequeue();
                    Console.WriteLine("Pierwszy pojazd z kierunku " + road.Key + " rusza i jedzie w kierunku " + a + ".");
                    break;
                }
            }
        }

        private static void DisplayAftermath()
        {
            Console.WriteLine("Korki na drogach:");
            Console.WriteLine("N: " + roads["N"].Count);
            Console.WriteLine("E: " + roads["E"].Count);
            Console.WriteLine("S: " + roads["S"].Count);
            Console.WriteLine("W: " + roads["W"].Count);
        }
    }
}
