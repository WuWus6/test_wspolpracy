﻿namespace skrzyzowanieTesty
{
    [TestClass]
    public sealed class Przypadek1
    {
        [TestMethod]
        public void AddCarTest()
        {
            Assert.AreEqual("Nowy pojazd nadjeżdża z kierunku N.", skrzyzowanie.Program.AddCar("N"));
        }

        [TestMethod]
        public void AddDirectionTest()
        {
            skrzyzowanie.Program.roads.Add("N", new Queue<string>());
            skrzyzowanie.Program.roads.Add("E", new Queue<string>());
            skrzyzowanie.Program.roads.Add("S", new Queue<string>());
            skrzyzowanie.Program.roads.Add("W", new Queue<string>());

            skrzyzowanie.Program.currentRoad = "N";

            Assert.AreEqual("Pojazd ten chce jechać w kierunku E.", skrzyzowanie.Program.AddDirection("E"));
        }

        [TestMethod]
        public void ChangeLightsTest()
        {
            Assert.AreEqual("Światła są zielone dla W, E.", skrzyzowanie.Program.ChangeLights("W, E"));
        }

        [TestMethod]
        public void MoveCarTest()
        {
            Assert.AreEqual("Nie rusza żaden pojazd.", skrzyzowanie.Program.MoveCar());
        }
    }
}
