﻿namespace skrzyzowanieTesty
{
    [TestClass]
    public sealed class Test1
    {
        [TestMethod]
        public void Case1()
        {
            skrzyzowanie.Program.roads.Add("N", new Queue<string>());
            skrzyzowanie.Program.roads.Add("E", new Queue<string>());
            skrzyzowanie.Program.roads.Add("S", new Queue<string>());
            skrzyzowanie.Program.roads.Add("W", new Queue<string>());

            var stringWriter = new StringWriter();
            Console.SetOut(stringWriter);

            // tura 1
            Console.WriteLine("Tura 1:");
            Console.WriteLine(skrzyzowanie.Program.AddCar("N"));
            Console.WriteLine(skrzyzowanie.Program.AddDirection("W"));
            Console.WriteLine(skrzyzowanie.Program.ChangeLights("W, E"));
            Console.WriteLine(skrzyzowanie.Program.MoveCar());
            Console.WriteLine();

            // tura 2
            Console.WriteLine("Tura 2:");
            Console.WriteLine(skrzyzowanie.Program.AddCar("E"));
            Console.WriteLine(skrzyzowanie.Program.AddDirection("W"));
            Console.WriteLine(skrzyzowanie.Program.ChangeLights("W, E"));
            Console.WriteLine(skrzyzowanie.Program.MoveCar());
            Console.WriteLine();

            // tura 3
            Console.WriteLine("Tura 3:");
            Console.WriteLine(skrzyzowanie.Program.AddCar("S"));
            Console.WriteLine(skrzyzowanie.Program.AddDirection("E"));
            Console.WriteLine(skrzyzowanie.Program.ChangeLights("N, S"));
            Console.WriteLine(skrzyzowanie.Program.MoveCar());
            Console.WriteLine();

            // aftermath
            Console.WriteLine();
            skrzyzowanie.Program.DisplayAftermath();

            string result = stringWriter.ToString();
            string expectedResult = "Tura 1:\r\nNowy pojazd nadjeżdża z kierunku N.\r\nPojazd ten chce jechać w kierunku W.\r\nŚwiatła są zielone dla W, E.\r\nNie rusza żaden pojazd.\r\n\r\nTura 2:\r\nNowy pojazd nadjeżdża z kierunku E.\r\nPojazd ten chce jechać w kierunku W.\r\nŚwiatła są zielone dla W, E.\r\nPierwszy pojazd z kierunku E rusza i jedzie w kierunku W.\r\n\r\nTura 3:\r\nNowy pojazd nadjeżdża z kierunku S.\r\nPojazd ten chce jechać w kierunku E.\r\nŚwiatła są zielone dla N, S.\r\nPierwszy pojazd z kierunku N rusza i jedzie w kierunku W.\r\n\r\n\r\nKorki na drogach:\r\nN: 0\r\nE: 0\r\nS: 1\r\nW: 0\r\n";

            Assert.AreEqual(expectedResult, result);
        }
    }
}
