import { useState } from 'react';
import './App.css';
import 'bootstrap/dist/css/bootstrap.css';

interface Image {
  id: number;
  alt: string;
  filename: string;
  category: 1 | 2 | 3;
  downloads: number;
}

function App() {
  const [images, setImages] = useState<Image[]>([
    { id: 1, alt: "Zwierzęta 1", filename: "src/assets/lion.jpg", category: 2, downloads: 33 },
    { id: 5, alt: "Samochody 1", filename: "src/assets/alfaromeo.jpg", category: 3, downloads: 201 },
    { id: 2, alt: "Zwierzęta 2", filename: "src/assets/lamb.jpg", category: 2, downloads: 100 },
    { id: 4, alt: "Kwiaty 2", filename: "src/assets/flower1.jpg", category: 1, downloads: 73 },
    { id: 6, alt: "Samochody 2", filename: "src/assets/ford.jpg", category: 3, downloads: 56 },
    { id: 3, alt: "Kwiaty 1", filename: "src/assets/flower.jpg", category: 1, downloads: 12 },
  ]);

  const [filters, setFilters] = useState({
    flowers: true,
    animals: true,
    cars: true,
  });

  const handleFilterChange = (category: keyof typeof filters) => {
    setFilters(prevFilters => ({
      ...prevFilters,
      [category]: !prevFilters[category],
    }));
  };

  const FilteredImages = images.filter((image) => {
    if (image.category === 1 && !filters.flowers) return false;
    if (image.category === 2 && !filters.animals) return false;
    if (image.category === 3 && !filters.cars) return false;
    return true;
  });

  const handleDownload = (id: number) => {
    setImages(prevImages =>
      prevImages.map(image =>
        image.id === id ? { ...image, downloads: image.downloads + 1 } : image
      )
    );
  };

  return (
    <div className='m-5'>
      <h1>Kategorie zdjęć:</h1>
      <br />

      <div className='form-check-inline form-switch'>
        <input
          className='form-check-input'
          type='checkbox'
          id='flowers'
          checked={filters.flowers}
          onChange={() => handleFilterChange('flowers')}
        />
        <label className='form-check-label' htmlFor='flowers'>
          Kwiaty
        </label>
      </div>

      <div className='form-check-inline form-switch'>
        <input
          className='form-check-input'
          type='checkbox'
          id='animals'
          checked={filters.animals}
          onChange={() => handleFilterChange('animals')}
        />
        <label className='form-check-label' htmlFor='animals'>
          Zwierzęta
        </label>
      </div>

      <div className='form-check-inline form-switch'>
        <input
          className='form-check-input'
          type='checkbox'
          id='cars'
          checked={filters.cars}
          onChange={() => handleFilterChange('cars')}
        />
        <label className='form-check-label' htmlFor='cars'>
          Samochody
        </label>
      </div>

      <div className='mt-3'>
        {FilteredImages.map((image) => (
          <div className='image' key={image.id}>
            <img src={image.filename} alt={image.alt} height='200px' />
            <h4>Liczba pobrań: {image.downloads}</h4>
            <button type='button' className='btn btn-success' onClick={() => handleDownload(image.id)}>
              Pobierz
            </button>
          </div>
        ))}
      </div>
    </div>
  );
}

export default App;
